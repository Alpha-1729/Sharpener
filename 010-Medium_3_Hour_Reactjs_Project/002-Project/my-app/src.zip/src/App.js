import React, { useState, useContext, useEffect, useCallback } from "react";
import NoteModal from "./components/Modals/AddNoteModal";
import NoteSearch from "./components/NoteSearch";
import NoteList from "./components/NoteList";
import NoteHeading from "./components/NoteHeading";
import NoteContext from "./store/note-context";
import NoteProvider from "./store/NoteProvider";
import AddNotes from "./components/AddNotes";

function App() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filteredNotes, setFilteredNotes] = useState([]);
  const noteCtx = useContext(NoteContext);

  // Synchronize filteredNotes with noteCtx.notes
  useEffect(() => {
    setFilteredNotes(noteCtx.notes);
  }, [noteCtx.notes]);

  const openModalHandler = () => setIsModalOpen(true);
  const closeModalHandler = () => setIsModalOpen(false);

  const searchHandler = useCallback((filteredNotes) => {
    setFilteredNotes(filteredNotes);
  }, []);

  const deleteHandler = (id) => {
    noteCtx.removeNote(id);
    setFilteredNotes((prevFiltered) =>
      prevFiltered.filter((note) => note.id !== id)
    );
  };

  const handleAddNote = (newNote) => {
    noteCtx.addNote(newNote); // Add the note to the context
    setFilteredNotes(noteCtx.notes);
    closeModalHandler(); // Close the modal after adding the note
  };

  return (
    <NoteProvider>
      <NoteHeading />
      <NoteSearch onSearch={searchHandler} />
      <AddNotes onAddNote={openModalHandler} />
      {isModalOpen && (
        <NoteModal
          onClose={closeModalHandler}
          onAddNote={handleAddNote}
        />
      )}
      <NoteList notes={filteredNotes} onDelete={deleteHandler} />
    </NoteProvider>
  );
}


export default App;
