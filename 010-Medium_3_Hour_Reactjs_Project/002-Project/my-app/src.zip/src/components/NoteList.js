import React from 'react';
import classes from './NoteList.module.css';

function NoteList({ notes, onDelete }) {
  console.log("Note reloaded");
  return (
    <div className={classes.noteList}>
      <h2>All Notes</h2>
      {notes.length === 0 && <p>No notes available.</p>}
      {notes.length > 0 && (
        <ul>
          {notes.map((note) => (
            <li key={note.id} className={classes.noteItem}>
              <div>
                <h3>{note.title}</h3>
                <p>{note.description}</p>
              </div>
              <button onClick={() => onDelete(note.id)}>Delete</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default NoteList;
